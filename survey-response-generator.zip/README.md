# 🧠 Survey Response Generator

A Python script that automatically generates synthetic, realistic survey response data and exports it to an Excel file for analysis, testing, or development purposes.

---

## 🚀 Features

- ✅ Generates **1,000+ fake survey responses**
- ✅ Simulates diverse attributes: names, emails, age, gender, education, etc.
- ✅ Injects **realistic business-related answers** with controlled randomness
- ✅ Outputs results to a structured `.xlsx` file
- ✅ Ideal for testing survey dashboards, ML training, and academic/demo purposes

---

## ⚙️ Built With

- [Python 3](https://www.python.org/)
- [pandas](https://pandas.pydata.org/) – for data handling & Excel export
- [Faker](https://faker.readthedocs.io/) – for generating realistic personal data
- [openpyxl](https://openpyxl.readthedocs.io/) – Excel writing engine

---

## 📦 Installation

Clone the repository:

```bash
git clone https://github.com/your-username/survey-response-generator.git
cd survey-response-generator
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Or manually:

```bash
pip install pandas faker openpyxl
```

---

## 🛠️ Usage

Simply run the script:

```bash
python generate_survey_responses.py
```

The script will generate a file named:

```
survey_responses.xlsx
```

in the root directory, containing 1,000 rows of mock survey data.

---

## 📂 Output Example

| Full Name             | Email                    | Age   | Gender | Education | Employment Status | Business Challenges              |
|-----------------------|--------------------------|-------|--------|-----------|-------------------|----------------------------------|
| Hussaini Muhammad     | hussainimuhammad29@gmail.com | 25-30 | Male   | Tertiary | Student           | Limited market access, Corruption |
| Amina Abba Muhammad   | aminaabbamuhammad64@gmail.com | 18-24 | Female | Secondary | Unemployed       | Lack of finance, Bureaucracy     |

---

## 🧪 Use Cases

- 🧱 Populate development dashboards
- 📊 Test survey data pipelines
- 🔬 Train machine learning models
- 🧪 Simulate analytics for UX or data demos
- 🎓 Practice data cleaning or statistical analysis

---

## 📄 License

This project is licensed under the MIT License. Feel free to use and modify it.

---

## 🙋‍♂️ Author

**Said Abba Ahmad**  
[GitHub](https://github.com/your-username) · [LinkedIn](https://linkedin.com/in/your-link)

---

> Star ⭐ this repo if you find it useful, and feel free to fork or contribute!